This will be a website that uses a camera to dynamically set a password using the webcam and will unlock once the
item has been scanned

